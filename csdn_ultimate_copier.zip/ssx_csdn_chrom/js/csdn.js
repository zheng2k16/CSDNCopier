window.onload = function (){
  var selection = "";	
  document.querySelectorAll("style")[1].remove()

  document.addEventListener("copy",function(e){
  	let text = e.clipboardData.getData('text');
  	if(text.indexOf("\r\n————————————————\r\n")!== -1) {
  		text = text.split('\r\n————————————————\r\n版权')[0];
  		e.clipboardData.setData('text',text);
  	}
  })

  document.addEventListener("mouseup",function(e){
  	if (e.button === 0) {
  		document.execCommand('copy')
		// if (window.getSelection().toString()!==selection) {
	  	// 	document.execCommand('copy')
	  	// }
  	}
  })
}
// 仅供学习,如有侵权,立即删除